<?php

$db = new SQLite3("C:\\xampp\\htdocs\\Group-20-NAMRC\\NAMRC\\NAMRC.db");