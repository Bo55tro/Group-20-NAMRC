<div class="container">
        <header class="header">
            <div class="logo">
                <img class="logo-img" src="logo.png" alt="Nuclear AMRC Logo">
            </div>
            <nav class="navigation">
                <ul class="left-options">
                    <li><a href="Health_and_safety_manager/HS_Login.php">Health and Safety manager</a></li>
                    <li><a href="Department_manager/DM_Login.php">Department manager</a></li>
                    <li><a href="Manufacturing_cell_manager/MCM_Login.php">Manufacturing cell manager</a></li>
                    <li><a href="Technical_Staff/Technical_Login.php">Technical Staff</a></li>
                    <li><a href="../Home.html">Back</a></li>
                </ul>
            </nav>
        </header>
    </div>